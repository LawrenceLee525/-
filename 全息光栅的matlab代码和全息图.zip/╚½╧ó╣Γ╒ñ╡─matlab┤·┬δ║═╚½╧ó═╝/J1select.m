function FA=J1select(A,tol)
% use the bisection method to find the root of the function
% Page 30,computer problem 7(Bisection method)
% input:
% f:the function that transform from the equation
% a,b:the left and right value of the interval which the root is in
% tol:the accuracy
% output:
% xc:the solution of the equation

% if sign(f(a)) * sign(f(b)) >=0
%     error('f(a)f(b)<0 not satisfied!')
% end
tol=10^-4;
NN=2000;
SS=linspace(0,1,NN); % ss (0,1) 2000����
FF=zeros(1,NN); % 2000Ԫ�� ����
    for i=1:NN
a=0;b=1.8412;
            while (b-a)/2 > tol
                c = (a + b)/2;
                if besselj(1,c)-0.58*SS(i)==0         % when f(c) == 0,c is a root of the function
                    break 
                end
                if (besselj(1,a)-0.58*SS(i))*(besselj(1,c)-0.58*SS(i)) < 0 || besselj(1,a)-0.58*SS(i)==0   % a and c form a new interval
                    b = c;
                else                  % c and b form a new interval
                    a = c;
                end
            end
            xc = (a+b)/2;             % the mid_rang is the root that we find
            FF(i)=xc;
    end
    
[M,N]=size(A);
FA=zeros(M,N);
mm=zeros(M,N);
    for i=1:M
        for j=1:N
            mm(i,j) =find(abs(0.58*SS-0.58*A(i,j))==min(abs(0.58*SS-0.58*A(i,j))));
            FA(i,j) = FF(mm(i,j));
        end
    end    
      
end
%%% ��=f(a)sin(��)�� J1(f(a))=0.5819a

            