clear all;close all;clc;

%% �ⳡ����
  [lambda,w0] = deal(532e-6,50e-6);
       [k,zR] = deal(2*pi/lambda,pi*w0^2/lambda);
            z = 0;
        [w,R] = deal(w0*sqrt(1+(z/zR)^2),z+zR^2/z);

%% SLM����
[D,H,V] = deal(18*w,1920,1080);
  [x,y] = deal(linspace(-D,D,H),linspace(-D*V/H,D*V/H,V));
  [X,Y] = meshgrid(x,y);
[phi,r] = cart2pol(X,Y);

%% ��������ʽ
[p,q,m0,n0,M,phi0,alpha,beta,PsiVortex]=deal(-1,5,18,30,6,0,pi/2,pi/2,0);
for K=0:M
	m=m0+p*K
	n=n0+q*K
    PsiVortex=PsiVortex+1/(2^(M/2))*sqrt(factorial(M)/(factorial(K)*factorial(M-K)))*exp(1i*K*phi0)*su2HLGbeam(m,n,X,Y,w,k,z,alpha,beta);
end
ph=angle(PsiVortex);
A=abs(PsiVortex)/max(max(abs(PsiVortex)));%�����һ

%% ��������ⳡ
figure(1)
subplot(1,2,1),imagesc(A.^2);colormap gray;axis equal;axis off;
subplot(1,2,2),imagesc(ph);colormap gray;axis equal;axis off;

%% ��ҫ��դ����
dx = 2*D/H;jiange=2;

%% һ��Bessel����������λ����
    F = J1select(A,10^-4);
  Hol = F.*sin(ph+2*pi*(X/(jiange*dx)));
  Hol = Hol-min(Hol(:));
Hol_1 = 0.5857*Hol/max(Hol(:));
imwrite(A.^2,"Intensity.bmp")
imwrite(ph,"Phase.bmp")
imwrite(Hol_1,strcat("Hol_(jiange=",string(jiange),")_(D=",string(D/w),"w",").bmp"))


%% ����ȫϢ��դͼ
figure(2)
subplot(1,2,1),imagesc(Hol); colormap gray; axis equal;
subplot(1,2,2),imagesc(Hol_1); colormap gray;axis equal;