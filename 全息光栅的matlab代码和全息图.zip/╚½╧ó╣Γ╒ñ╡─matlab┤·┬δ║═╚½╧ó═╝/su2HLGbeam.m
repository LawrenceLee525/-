function [HLG] = gHLGbeam(n,m,X,Y,w0,k,z,alpha,beta)
HLG=0;
N=n+m;
for m1=0:N
    d=0;
    for v=max(0,m1-n):min(N-n,m1)
        d=d+(-1)^v*((cos(beta/2))^(N-n+m1-2*v))*((sin(beta/2))^(n-m1+2*v))/(factorial(v)*factorial(N-n-v)*factorial(m1-v)*factorial(n-m1+v));
    end
    d=(factorial(m1)*factorial(N-m1)*factorial(n)*factorial(N-n))^0.5*d;
    HLG=HLG+exp(-1i*m1*alpha)*d*HGbeam(m1,N-m1,X,Y,w0,k,z);
end

end

