function H=H_gen(n,x)
syms xx
Hn=(-1)^n*exp(xx^2)*diff(exp(-xx^2),xx,n);
f=matlabFunction(Hn);
if n==0
    H=1;
else
    H=f(x);
end
